
# About

This repository contains functionality to operate pull on MISP feeds and servers.

To be able to use this functionality on MISP your user needs to have admin privileges.


# Set up

The following needs to be done when setting up this repo for the first time.

1. Set up virtualenv. With python3 you can set this up with.


		python3 -m venv venv



2. Jump into virtualenv and then install requirements from requirements.txt

		source venv/bin/activate
		pip install -r requirements.txt


3. Create a secrects.ini file in root path. The file requires the following parameteres
PS: the settings.json have the object field name "instance". If this is e.g. is set to "misp_prod", then you also must have section named [misp_prod] in the secrets.ini with the API-key


		[misp_prod]
		apikey=

		[misp_ext]
		apikey=





4. Set up systemd service scripts. We should make a .service and .timer service script under /etc/systemd/system/


	4.1. misp_scheduler.service


		[Unit]
		Description=Perform MISP pull jobs and sync info from connected servers and feeds
		OnFailure=unit-status-failure@%n.service

		[Service]
		Type=oneshot
		User=tools
		Group=tools
		WorkingDirectory=/opt/misp_schedules
		ExecStart=/opt/misp_schedules/venv/bin/python perform_pull.py




	4.2 misp_scheduler.timer


		[Unit]
		Description=Perform MISP pull jobs towards different sync server and feeds.

		[Timer]
		OnCalendar=*:0/30

		[Install]
		WantedBy=timers.target



5. Remember to test and enable the systemd service scripts with "enable" and "start" commands.


