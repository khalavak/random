
import sys
import json
import requests
import configparser

from datetime import datetime
from datetime import timedelta


class MispSchedules():

    def __init__(self):

        self.settings_file = "settings.json"

        self.config = configparser.ConfigParser()
        self.config.read('secrets.ini')


    def get_settings(self):

        with open(self.settings_file, 'r') as f:
            data = f.read()

        return json.loads(data)


    def update_settings(self, content):

        with open(self.settings_file, 'w') as f:
            f.write(content)


    def perform_pull(self, content):

        headers = {
            "Authorization" : self.config.get(content['instance'], 'apikey'),
            "User-Agent" : "NFCERT Pull Schedule Worker",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        url = content['url']
        print("Performing pull now on: {0} - {1}".format(content['url'], content['description']))
        r = requests.get(
            url,
            headers=headers
        )

        print(json.dumps(r.json(), indent=4) )


    def main(self):

        settings = self.get_settings()
        for job in settings:
            now = datetime.now()

            last_checked = job['last_checked']
            if last_checked == 0:
                last_checked = now
                job['last_checked'] = last_checked.strftime('%Y-%m-%d %H:%M:%S.%f')

            else:
                last_checked = datetime.strptime(last_checked, '%Y-%m-%d %H:%M:%S.%f')

            time_back = (now - timedelta(hours=job['frequency']))
            if last_checked >= time_back:
                print("{0} is not older than {1} - skip performing pull".format(last_checked, time_back))
                continue
            else:
                print("Starting to perform pull work on {0} - {1}".format(job['url'], job['description']))
                self.perform_pull(job)
                job['last_checked'] = now.strftime('%Y-%m-%d %H:%M:%S.%f')
                print("Updating last_checked to: {0}".format(job['last_checked']))

        self.update_settings(json.dumps(settings, indent=4))


if __name__ == "__main__":
    '''
    This script is made to easily add schedule jobs towards multiple different MISP instances.
    On top level a systemctl timer script is running on "/etc/systemd/system/ misp_scheduler.service and .timer"

    Details:
    In settings.json we add what kind of MISP server/feed we want to pull. example on adding a new pull job.

    [
        {
            "url": "https://misp.nfcert.org/servers/pull/<id>/incremental",
            "instance": "misp_test",
            "description": "Pull data from MISP Server <id>",
            "frequency": 2,
            "last_checked": 0
        }
    ]

    From the example above you need to add the correct url, instance and frequency. Description should contain information about the server/feed you are polling from.
        * The "url" field is the complete url for where to perform the pull. You will find details under e.g. https://misp.nfcert.org/servers/ on which <id> to use.
        * The "frequency" field defines how often a pull should occour. setting it to 2 means every 2 hours it will be performing a pull.
            ps. last_checked MUST be defined to 0 when first adding a new pull job. after it's first run it will automatically update with a time which is used for checking
            if it should perform a new pull job or wait based on the defined interval integer.

        * The "instance" field is also important. when adding e.g. misp_test as instance, we need to make sure that this field also exist inside the secrets.ini file.
            for the secrects.ini it would typically be like this.
                [misp_test]
                apikey=xyz
    '''
    ms = MispSchedules()
    ms.main()
